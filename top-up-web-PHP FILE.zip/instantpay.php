<?php 
include 'common/header.php';
if(!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }
if($_SERVER['REQUEST_METHOD'] != 'POST') { header("Location: index.php"); exit; }

// Receive Data
$total = $_POST['total_amount'];
$game_id = $_POST['game_id'];
$product_id = $_POST['product_id'];
$player_id = $_POST['player_id'];
$game_name = isset($_POST['game_name']) ? $_POST['game_name'] : '';

// Resolve Product Name
$product_name = "";
if($product_id != 0) {
    // Normal Game Order
    $prod = $conn->query("SELECT name FROM products WHERE id=$product_id")->fetch_assoc();
    $product_name = $prod ? $prod['name'] : 'Unknown Product';
} else {
    // Wallet Deposit
    $product_name = "Balance Add Request";
    if(empty($game_name)) $game_name = "Wallet";
}
?>

<div class="container mx-auto px-4 py-6 mb-20">
    <div class="bg-white p-6 rounded-xl shadow-lg mb-6 text-center border-t-4 border-blue-600">
        <p class="text-gray-500 mb-1 text-sm uppercase font-bold">Total Payable Amount</p>
        <h1 class="text-4xl font-bold text-blue-600 my-2"><?php echo getSetting($conn, 'currency').$total; ?></h1>
        <div class="inline-block bg-gray-100 px-3 py-1 rounded-full text-xs text-gray-600 font-medium">
            <?php echo $game_name; ?> • <?php echo $product_name; ?>
        </div>
    </div>

    <form action="order.php" method="POST" id="payForm">
        <input type="hidden" name="action" value="create_order">
        <input type="hidden" name="game_id" value="<?php echo $game_id; ?>">
        <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
        <input type="hidden" name="amount" value="<?php echo $total; ?>">
        <input type="hidden" name="player_id" value="<?php echo $player_id; ?>">
        
        <h3 class="font-bold text-gray-700 mb-3 flex items-center gap-2">
            <i class="fa-solid fa-wallet text-blue-500"></i> Select Payment Method
        </h3>
        
        <div class="grid grid-cols-2 gap-4 mb-6">
            <?php 
            $methods = $conn->query("SELECT * FROM payment_methods");
            while($m = $methods->fetch_assoc()): ?>
            <label class="cursor-pointer group">
                <input type="radio" name="payment_method" value="<?php echo $m['name']; ?>" 
                       data-number="<?php echo $m['number']; ?>" 
                       data-qr="<?php echo $m['qr_image']; ?>" 
                       data-desc="<?php echo $m['short_desc']; ?>"
                       class="peer sr-only" required onchange="showPaymentDetails(this)">
                
                <div class="border-2 border-gray-100 rounded-xl p-4 flex flex-col items-center gap-2 hover:bg-gray-50 peer-checked:border-blue-600 peer-checked:bg-blue-50 transition relative overflow-hidden">
                    <?php if($m['logo']): ?>
                        <img src="<?php echo $m['logo']; ?>" class="h-10 object-contain">
                    <?php else: ?>
                        <span class="font-bold text-gray-700"><?php echo $m['name']; ?></span>
                    <?php endif; ?>
                    
                    <div class="absolute top-2 right-2 text-blue-600 opacity-0 peer-checked:opacity-100 transition">
                        <i class="fa-solid fa-circle-check"></i>
                    </div>
                </div>
            </label>
            <?php endwhile; ?>
        </div>

        <div id="paymentDetails" class="hidden bg-white p-6 rounded-xl shadow-lg border border-blue-100 animate-fade-in">
            <div class="text-center mb-6">
                <img id="qrImg" src="" class="w-32 h-32 mx-auto mb-3 hidden rounded-lg border p-1">
                <p class="text-xs text-gray-500 mb-1 font-bold uppercase">Send Money To</p>
                
                <div class="flex items-center justify-center gap-3 bg-gray-100 p-3 rounded-lg border border-gray-200">
                    <span id="payNumber" class="font-mono font-bold text-xl text-gray-800 tracking-wider"></span>
                    <button type="button" onclick="navigator.clipboard.writeText(document.getElementById('payNumber').innerText); alert('Number Copied!');" class="text-blue-600 hover:text-blue-800 transition">
                        <i class="fa-regular fa-copy text-lg"></i>
                    </button>
                </div>
                <p id="payDesc" class="text-xs text-orange-600 mt-2 font-medium bg-orange-50 inline-block px-2 py-1 rounded"></p>
            </div>

            <div class="space-y-4">
                <div>
                    <label class="block text-xs font-bold text-gray-500 mb-1">Your Wallet Number</label>
                    <input type="text" name="wallet_number" placeholder="e.g. 017xxxxxxxx" class="w-full border p-3 rounded-lg focus:outline-none focus:border-blue-500 bg-gray-50" required>
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-500 mb-1">Transaction ID (TrxID)</label>
                    <input type="text" name="trx_id" placeholder="e.g. 8XHS..." class="w-full border p-3 rounded-lg focus:outline-none focus:border-blue-500 bg-gray-50" required>
                </div>
                <button type="submit" class="w-full bg-blue-600 text-white py-3.5 rounded-xl font-bold shadow-lg hover:bg-blue-700 hover:shadow-xl transition transform active:scale-95">
                    Confirm Payment
                </button>
            </div>
        </div>
    </form>

    <div class="text-center py-4 text-xs text-gray-400 mt-6">
        <p>&copy; 2025 <?php echo getSetting($conn, 'site_name'); ?>.</p>
        <a href="https://t.me/mraiprime" target="_blank" class="text-blue-400 hover:text-blue-600 transition decoration-none">
            Developed by Mr Ai Prime
        </a>
    </div>
</div>

<script>
    function showPaymentDetails(input) {
        const details = document.getElementById('paymentDetails');
        details.classList.remove('hidden');
        
        document.getElementById('payNumber').innerText = input.getAttribute('data-number');
        document.getElementById('payDesc').innerText = input.getAttribute('data-desc');
        
        const qr = input.getAttribute('data-qr');
        const qrImg = document.getElementById('qrImg');
        if(qr && qr !== "") {
            qrImg.src = qr;
            qrImg.classList.remove('hidden');
        } else {
            qrImg.classList.add('hidden');
        }
        
        // Smooth scroll to details
        details.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
</script>

<?php include 'common/bottom.php'; ?>
