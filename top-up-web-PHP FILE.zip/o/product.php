<?php include 'common/header.php'; 

// Add Product
if(isset($_POST['add'])) {
    $gid = $_POST['game_id'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $conn->query("INSERT INTO products (game_id, name, price) VALUES ($gid, '$name', '$price')");
}

// Delete Product
if(isset($_GET['del'])) {
    $id = $_GET['del'];
    $conn->query("DELETE FROM products WHERE id=$id");
    echo "<script>window.location='product.php';</script>";
}
?>

<div class="grid grid-cols-1 md:grid-cols-3 gap-6">
    <div class="md:col-span-1 bg-white p-6 rounded shadow h-fit">
        <h3 class="font-bold mb-4 border-b pb-2">Add Product</h3>
        <form method="POST" class="space-y-4">
            <div>
                <label class="block text-xs font-bold text-gray-500">Select Game</label>
                <select name="game_id" class="w-full border p-2 rounded bg-gray-50" required>
                    <?php 
                    $games = $conn->query("SELECT * FROM games");
                    while($g = $games->fetch_assoc()): ?>
                        <option value="<?php echo $g['id']; ?>"><?php echo $g['name']; ?> (<?php echo $g['type']; ?>)</option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div>
                <label class="block text-xs font-bold text-gray-500">Package Name</label>
                <input type="text" name="name" placeholder="e.g. 100 Diamonds / Weekly" class="w-full border p-2 rounded" required>
            </div>
            <div>
                <label class="block text-xs font-bold text-gray-500">Selling Price</label>
                <input type="number" step="0.01" name="price" placeholder="0.00" class="w-full border p-2 rounded" required>
            </div>
            <button type="submit" name="add" class="w-full bg-blue-600 text-white py-2 rounded font-bold hover:bg-blue-700">Add Product</button>
        </form>
    </div>

    <div class="md:col-span-2 bg-white p-6 rounded shadow">
        <h3 class="font-bold mb-4 border-b pb-2">Product List</h3>
        <div class="overflow-y-auto max-h-[500px]">
            <table class="w-full text-sm text-left">
                <thead class="bg-gray-100 text-gray-600 sticky top-0">
                    <tr>
                        <th class="p-2">Game</th>
                        <th class="p-2">Package Name</th>
                        <th class="p-2">Price</th>
                        <th class="p-2 text-right">Action</th>
                    </tr>
                </thead>
                <tbody class="divide-y">
                    <?php 
                    $prods = $conn->query("SELECT p.*, g.name as gname FROM products p JOIN games g ON p.game_id = g.id ORDER BY p.id DESC");
                    while($p = $prods->fetch_assoc()): ?>
                    <tr class="hover:bg-gray-50">
                        <td class="p-2 font-bold text-gray-700"><?php echo $p['gname']; ?></td>
                        <td class="p-2"><?php echo $p['name']; ?></td>
                        <td class="p-2 text-blue-600 font-bold"><?php echo getSetting($conn, 'currency').$p['price']; ?></td>
                        <td class="p-2 text-right">
                            <a href="?del=<?php echo $p['id']; ?>" onclick="return confirm('Delete this package?')" class="text-red-500 bg-red-100 p-1.5 rounded hover:bg-red-200"><i class="fa-solid fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body></html>
