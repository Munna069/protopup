<?php include 'common/header.php'; 

if(isset($_GET['del'])) {
    $conn->query("DELETE FROM users WHERE id=".$_GET['del']);
    echo "<script>window.location='user.php';</script>";
}
?>

<div class="bg-white rounded shadow overflow-hidden">
    <table class="w-full text-sm text-left">
        <thead class="bg-gray-100 border-b">
            <tr>
                <th class="p-3">ID</th>
                <th class="p-3">Name / Email</th>
                <th class="p-3">Phone</th>
                <th class="p-3">Balance</th>
                <th class="p-3">Joined</th>
                <th class="p-3 text-right">Action</th>
            </tr>
        </thead>
        <tbody class="divide-y">
            <?php $users = $conn->query("SELECT * FROM users ORDER BY id DESC");
            while($u = $users->fetch_assoc()): ?>
            <tr class="hover:bg-gray-50">
                <td class="p-3"><?php echo $u['id']; ?></td>
                <td class="p-3">
                    <div class="font-bold"><?php echo $u['name']; ?></div>
                    <div class="text-xs text-gray-500"><?php echo $u['email']; ?></div>
                </td>
                <td class="p-3"><?php echo $u['phone']; ?></td>
                <td class="p-3 text-green-600 font-bold"><?php echo getSetting($conn, 'currency').$u['balance']; ?></td>
                <td class="p-3 text-gray-400 text-xs"><?php echo date('d M Y', strtotime($u['created_at'])); ?></td>
                <td class="p-3 text-right">
                    <a href="?del=<?php echo $u['id']; ?>" onclick="return confirm('Ban/Delete User?')" class="text-white bg-red-500 px-3 py-1 rounded text-xs">Delete</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body></html>
